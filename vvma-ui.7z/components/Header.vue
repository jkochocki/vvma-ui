<template>
    <div id="header" :class="{ 'nav-transparent': !showNavbar, 'nav-opaque': showNavbar}">
        <b-row id="titleRow" align-content="center">
            <b-col align-self="center" align="center">
                <b-navbar-brand href="#" class="vvma-brand">Volunteer Ventures of MA</b-navbar-brand>
            </b-col>
            <b-col align="center">
                <b-icon icon="instagram" scale="1.5" class="pr-4"></b-icon>
                <b-icon icon="facebook" scale="1.5" class="pr-4"></b-icon>
                <b-button squared variant="success" to="/donate">Donate</b-button>
            </b-col>
        </b-row>
        <b-row id="navigation">
            <b-col>
                <b-nav pills align-content="center" align="center">
                    <b-nav-item link-classes="navigation-item" to="/">HOME</b-nav-item>
                    <b-dropdown id="nav-dd" toggle-class="nav-dd" menu-class="nav-dd-menu" text="DESK MATES" class="m-md-2">
                        <b-dropdown-item link-class="dd-item" to="/deskmates">ABOUT</b-dropdown-item>
                        <b-dropdown-item link-class="dd-item" to="/deskmates/builders">BUILDERS</b-dropdown-item>
                        <b-dropdown-item link-class="dd-item" to="/partners">RECIPIENTS</b-dropdown-item>
                    </b-dropdown>
                    <b-dropdown id="nav-dd" toggle-class="nav-dd" menu-class="nav-dd-menu" text="ABOUT US" class="m-md-2">
                        <b-dropdown-item link-class="dd-item" to="/leadership">LEADERSHIP</b-dropdown-item>
                        <b-dropdown-item link-class="dd-item" to="/sponsors">SPONSORS</b-dropdown-item>
                        <b-dropdown-item link-class="dd-item" to="/partners">COMMUNITY PARTNERS</b-dropdown-item>
                    </b-dropdown>
                    <b-nav-item link-classes="navigation-item" to="/contact">CONTACT US</b-nav-item>
                    <b-nav-item link-classes="navigation-item" to="/gallery">GALLERY</b-nav-item>
                </b-nav>
            </b-col>
        </b-row>
    </div>
</template>

<script>
export default {
    data() {
        return {
            showNavbar: false
        };
    },
    methods: {
        handleScroll() {
            window.pageYOffset > 0 ? this.showNavbar = true: this.showNavbar = false;
            console.log(this.showNavbar);
        }
    },
    beforeMount() {
        window.addEventListener("scroll", this.handleScroll);
    },
    beforeDestroy() {
        window.removeEventListener("scroll", this.handleScroll);
    }
};
</script>


<style>

#header {
    position: fixed;
    width: 100%;
}

#titleRow {
    height: 90px;
}

#navigation {
    height: 70px;
}

.nav-opaque {
    background-color: #fff;
    border-bottom: 1px solid #999;
    transition: all 1s;
}

.nav-transparent {
    background-color: rgba(255, 255, 255, 0);
    transition: all 1s;
}

.navigation-item {
    font-size: large;
}

.navigation-item:hover, .nav-dd:hover {
    color: #DD6F40 !important;
}

.nav-opaque > div > div > .vvma-brand, 
.nav-opaque > div > div > svg.bi-instagram, 
.nav-opaque > div > div > svg.bi-facebook,
.nav-opaque > div > div > ul > li > .navigation-item,
.nav-opaque > div > div > ul > div > .nav-dd,
.nav-opaque > div > div > ul > div.show > .nav-dd {
    color: #00134E;
    transition: all 1s;
}


.nav-transparent > div > div > .vvma-brand, 
.nav-transparent > div > div > svg.bi-instagram, 
.nav-transparent > div > div > svg.bi-facebook,
.nav-transparent > div > div > ul > li > .navigation-item,
.nav-transparent > div > div > ul > div > .nav-dd {
    color: #FFF;
    transition: all 1s;
}

.nav-dd {
    font-size: large;
    border: none;
    background: none;
    cursor: pointer;
    margin: 0;
    padding: 0;
}

.nav-dd:hover, .nav-dd:focus, .nav-dd:active, .nav-dd:focus-within, .show > .nav-dd {
    background: none !important;
}

.dd-item {
    color: #00134E;
}



</style>