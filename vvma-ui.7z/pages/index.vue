<template>
    <div>
        <br>
        <b-row cols="1">
            <h4>Volunteer Ventures is a rapidly growing volunteer-work organization committed to organizing individuals and groups to give back to underserved communities. [example headline]</h4>
        </b-row>
        <br>
        <b-row cols="1">
            <h5>[Example call to action] Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</h5>
        </b-row>
        <br>
        <b-row cols="1">
            <p>
                Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.
            </p>
        </b-row>
    </div>
</template>

<script>
export default {};
</script>

<style>

</style>
