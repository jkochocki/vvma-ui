<template>
    <div>
        <h3>Donate</h3>
    </div>
</template>

<script>
export default {
    
}
</script>

<style>

</style>